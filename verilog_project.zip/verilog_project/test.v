'timescale 1ns/1ps
module test;

reg clk;

initial begin
    clk = 0;
end

always #5 clk = ~clk;

initial begin
    $dumpfile("adder_wave.vcd");
    $dumpvars(0, test);

    #50;
    $finish;
end

endmodule
